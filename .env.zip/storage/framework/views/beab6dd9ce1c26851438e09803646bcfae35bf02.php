<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>
		
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" type="text/css">
		<link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet" type="text/css">
		<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>" type="text/css">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.theme.default.css')); ?>" type="text/css">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/slimNav_sk78.css')); ?>">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    
</head><?php /**PATH D:\KMProject\nifticals\resources\views/frontend/include/head.blade.php ENDPATH**/ ?>